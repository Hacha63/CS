using System.Windows.Forms;

namespace PracticaEvaluable2
{
    public partial class MainForm : Form
    {
        private UsersRepository Repository;

        public MainForm()
        {
            InitializeComponent();
            Repository = UsersRepository.GetInstance();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitUsersRepository();
            BuildMenu();
            InitListBoxes();
        }

        private void InitUsersRepository()
        {
            for (int i = 0; i < 100; i++)
            {
                var name = RandomUserDataGenerator.GetRandomName();
                AddStudent(Repository.GetNextUserId(), name, RandomUserDataGenerator.NameToMail(name), RandomUserDataGenerator.NameToCourse(name));
            }

            for (int i = 0; i < 5; i++)
            {
                var name = RandomUserDataGenerator.GetRandomName();
                AddAdmin(Repository.GetNextUserId(), name, RandomUserDataGenerator.NameToMail(name), "DAM"); ;
            }
        }

        private void AddStudent(int id, string name, string mail, string course)
        {
            var s = new Student(id, name, mail, course);
            Repository.Add(s);
        }

        private void AddAdmin(int id, string name, string mail, string department)
        {
            var a = new Admin(id, name, mail, department);
            Repository.Add(a);
        }

        private void BuildMenu()
        {
            var menu = new MenuStrip();
            var file = new ToolStripMenuItem("File");
            menu.Items.Add(file);

            var open = new ToolStripMenuItem("Open");
            open.ShortcutKeys = Keys.Control | Keys.O;
            open.Click += (s, e) => ShowDataGridForm();
            

            file.DropDownItems.Add(open);
            file.DropDownItems.Add(new ToolStripSeparator());

            var exit = new ToolStripMenuItem("Exit");
            exit.ShortcutKeys = Keys.Alt | Keys.F4;
            exit.Click += (s, e) => Application.Exit();

            file.DropDownItems.Add(exit);

            this.Controls.Add(menu);
        }

        private void InitListBoxes()
        {
            listBoxAdmins.Items.Clear();
            listBoxStudents.Items.Clear();
            Repository.GetStudents().ForEach(s => listBoxStudents.Items.Add(s.ToString()));
            Repository.GetAdmins().ForEach(s => listBoxAdmins.Items.Add(s.ToString()));
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.O)
            {
                ShowDataGridForm();
            }

            if (e.Alt && e.KeyCode == Keys.F4)
            {
                Application.Exit();
            }
        }

        private void ShowDataGridForm() {
            var usersForm = new UsersDataGridForm(this);
            usersForm.ShowDialog();
        }

        public void RefreshFormData()
        {
            InitListBoxes();
        }
    }
}
