using System.Windows.Forms;

namespace menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "Menu";

            MenuStrip menu = new MenuStrip();
            ToolStripMenuItem arxiu = new ToolStripMenuItem("Arxiu");
            ToolStripMenuItem nou = new ToolStripMenuItem("Nou");
            ToolStripMenuItem obrir = new ToolStripMenuItem("Obrir");
            ToolStripMenuItem sortir = new ToolStripMenuItem("Sortir");
            nou.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N;

            ToolStripMenuItem edita = new ToolStripMenuItem("Edita");
            ToolStripMenuItem copiar = new ToolStripMenuItem("Copiar");
            ToolStripMenuItem enganxar = new ToolStripMenuItem("Enganxar");

            ToolStripMenuItem ajuda = new ToolStripMenuItem("Ajuda");
            ToolStripMenuItem sobre = new ToolStripMenuItem("Sobre");

            arxiu.DropDownItems.Add(nou);
            arxiu.DropDownItems.Add(obrir);
            arxiu.DropDownItems.Add(new ToolStripSeparator());
            arxiu.DropDownItems.Add(sortir);

            edita.DropDownItems.Add(copiar);
            edita.DropDownItems.Add(enganxar);

            ajuda.DropDownItems.Add(sobre);


            menu.Items.Add(arxiu);
            menu.Items.Add(edita);
            menu.Items.Add(ajuda);

            nou.Click += (s, e) => ShowErrorMessage("Nou", "Acci�: Nou");
            obrir.Click += (s, e) => ShowErrorMessage("Obrir", "Acci�: Obrir");
            sortir.Click += (s, e) => this.Close();

            copiar.Click += (s, e) => ShowErrorMessage("Copiar", "Acci�: Copiar");
            enganxar.Click += (s, e) => ShowErrorMessage("Enganxar", "Acci�: Enganxar");

            sobre.Click += (s, e) => ShowErrorMessage("Sobre", "Informaci�");

            this.Controls.Add(menu);
        }

        private void ShowErrorMessage(String title, String message)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
