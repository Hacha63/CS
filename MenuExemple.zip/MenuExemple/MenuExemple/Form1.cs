namespace MenuExemple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuArxiu_Click(object sender, EventArgs e)
        {

        }

        private void mnuObrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show($"Has abierto el archivo: {openFileDialog.FileName}");
            }
        }

        private void mnuSortir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}


