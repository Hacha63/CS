﻿namespace MenuExemple
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            mnuArxiu = new ToolStripMenuItem();
            mnuObrir = new ToolStripMenuItem();
            mnuSortir = new ToolStripMenuItem();
            edicióToolStripMenuItem = new ToolStripMenuItem();
            copiaToolStripMenuItem = new ToolStripMenuItem();
            pegaToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { mnuArxiu, edicióToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(433, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // mnuArxiu
            // 
            mnuArxiu.DropDownItems.AddRange(new ToolStripItem[] { mnuObrir, mnuSortir });
            mnuArxiu.Name = "mnuArxiu";
            mnuArxiu.Size = new Size(47, 20);
            mnuArxiu.Text = "Arxiu";
            mnuArxiu.Click += mnuArxiu_Click;
            // 
            // mnuObrir
            // 
            mnuObrir.Name = "mnuObrir";
            mnuObrir.Size = new Size(180, 22);
            mnuObrir.Text = "Obrir";
            mnuObrir.Click += mnuObrir_Click;
            // 
            // mnuSortir
            // 
            mnuSortir.Name = "mnuSortir";
            mnuSortir.Size = new Size(180, 22);
            mnuSortir.Text = "Sortir";
            mnuSortir.Click += mnuSortir_Click;
            // 
            // edicióToolStripMenuItem
            // 
            edicióToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { copiaToolStripMenuItem, pegaToolStripMenuItem });
            edicióToolStripMenuItem.Name = "edicióToolStripMenuItem";
            edicióToolStripMenuItem.Size = new Size(51, 20);
            edicióToolStripMenuItem.Text = "Edició";
            // 
            // copiaToolStripMenuItem
            // 
            copiaToolStripMenuItem.Name = "copiaToolStripMenuItem";
            copiaToolStripMenuItem.Size = new Size(105, 22);
            copiaToolStripMenuItem.Text = "Copia";
            // 
            // pegaToolStripMenuItem
            // 
            pegaToolStripMenuItem.Name = "pegaToolStripMenuItem";
            pegaToolStripMenuItem.Size = new Size(105, 22);
            pegaToolStripMenuItem.Text = "Pega";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(433, 361);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem mnuArxiu;
        private ToolStripMenuItem mnuObrir;
        private ToolStripMenuItem mnuSortir;
        private ToolStripMenuItem edicióToolStripMenuItem;
        private ToolStripMenuItem copiaToolStripMenuItem;
        private ToolStripMenuItem pegaToolStripMenuItem;
    }
}
